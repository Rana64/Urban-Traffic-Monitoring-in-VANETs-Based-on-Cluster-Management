<?php
	// Single line comments
	/* This is multi line 
	comment */
	// int a = 10;
	// $a = 10;
	// $A = 20.5;
	// echo var_dump(is_int($a));
	// echo var_dump(is_float($A));
	// echo var_dump($a);
	// $myStr = "Pakistan is our dear homeland";
	// echo str_word_count($myStr);
	//echo strlen($myStr);
	// echo var_dump($myStr);
	//Concatenation
	// echo "Value in A = " . $A . "Value in a = ".$a;
	// echo("Hello This is Testing");
	// print("Hello World");
	// print "Hello World";
	// $pi = 3.1416;
	// echo var_dump($pi);
	//Basic Math
	// echo "Value of PI = ".pi();
	// echo "Square Root of 64 = ".sqrt(64);
	// $r = 0.60;
	// echo(round($r));

	// define("ContactNo", "03001234567");
	// echo ContactNo;

	// $a = 10;
	// $b = 200;
	// $c = $a + $b;
	// echo "Sum is = ".$c;
	//echo $a**2;
	// if ($a%2 == 0) {
	// 	print("Even");
	// }
	// else
	// {
	// 	print("Odd");
	// }
	//echo date("yy");

	// $a = 100;
	// $b = 10;
// == means comparison
	// if ($a==$b) {
	// 	print("Numbers are Same");
	// }
	// else
	// {
	// 	print("Numbers are Different");
	// }
	// $myCountry = "Pakistan";
	// switch ($myCountry) {
	// 	case 'USA':
	// 		print("You are a citizen of USA");
	// 		break;
	// 	case 'UK':
	// 		print("You are a citizen of UK");
	// 		break;
	// 	case 'Pakistan':
	// 		print("You are a citizen of Pakistan");
	// 		break;
	// 	default:
	// 		print("You are not belonging to all above mentioned countries");
	// 		break;
	// }

	// $a = 1;
	// while ($a <= 10) {
	// 	echo "The number is: $a <br>";
	// 	$a++;
	// }
	// $a = 1;
	// do
	// {
	// 	echo "The number is $a <br>";
	// 	$a++;
	// }
	// while ($a <= 100);

	// for ($i= 0; $i <= 10; $i++) { 
	// 	echo($a."<br>");
	// }
?>